CS2D is freeware
Copyright � 2002-2021 Unreal Software
www.UnrealSoftware.de
www.CS2D.com

- Using Sounds/Textures from the original Counter-Strike Copyright � Valve Corporation

- Using BNetEx Copyright � Oliver Skawronek & Inkubus

- Using Lua Copyright � 1994�2010 Lua.org, PUC-Rio.
  License: http://www.lua.org/license.html
